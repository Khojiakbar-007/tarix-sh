exports.id = 754;
exports.ids = [754];
exports.modules = {

/***/ 458:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "header_header__bp5X_"
};


/***/ }),

/***/ 4508:
/***/ ((module) => {

// Exports
module.exports = {
	"mainButton": "mainButton_mainButton__Dtlyc"
};


/***/ }),

/***/ 4584:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: ./node_modules/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(5893);
// EXTERNAL MODULE: ./node_modules/next/font/local/target.css?{"path":"src\\pages\\_app.tsx","import":"","arguments":[{"src":"../fonts/proximanova_regular.ttf","variable":"--font-surt-bold"}],"variableName":"surt"}
var proximanova_regular_ttf_variable_font_surt_bold_variableName_surt_ = __webpack_require__(6633);
var proximanova_regular_ttf_variable_font_surt_bold_variableName_surt_default = /*#__PURE__*/__webpack_require__.n(proximanova_regular_ttf_variable_font_surt_bold_variableName_surt_);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: ./src/styles/index.scss
var styles = __webpack_require__(7195);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
var external_react_default = /*#__PURE__*/__webpack_require__.n(external_react_);
// EXTERNAL MODULE: ./src/widgets/header/header.module.scss
var header_module = __webpack_require__(458);
var header_module_default = /*#__PURE__*/__webpack_require__.n(header_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./src/widgets/header/assets/Vector (10).png
/* harmony default export */ const Vector_10_ = ({"src":"/_next/static/media/Vector (10).fff95d91.png","height":16,"width":16,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAX0lEQVR42kXIOwqEUBBE0WJmYFyAgrglExdl5PLUwNgPiGKkmXifBQZy4dBd4osoONit+Mj8GQhu8iUhIhaCm5/hh8jpGa0/8ZQQWydSSmo2VhoqMtESeOtkTi4AexJu1J5gmnQtuFoAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});
;// CONCATENATED MODULE: ./src/widgets/header/assets/ic_baseline-remove-red-eye.png
/* harmony default export */ const ic_baseline_remove_red_eye = ({"src":"/_next/static/media/ic_baseline-remove-red-eye.e850f4ff.png","height":24,"width":24,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAQAAABuBnYAAAAAWElEQVR42l2NsQ3AIAwEiTIVbIRERUNDQQc1YoqMSHHJi4QmtvS+f1m24eA0X3FyvOCoNOzOB5NClnZZEjeeSx1E0RA1wgq8KGmHziRTpGNfsTQqbpn/2wdSy0EJrIUcHQAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":8});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: ./src/widgets/home/components/mainButton/index.tsx
var mainButton = __webpack_require__(6501);
;// CONCATENATED MODULE: ./src/widgets/header/assets/Icon.tsx


const Icon = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
        width: "28",
        height: "17",
        viewBox: "0 0 28 17",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("rect", {
                width: "20",
                height: "3",
                rx: "1.5",
                fill: "white"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("path", {
                d: "M0 8.5C0 7.67157 0.671573 7 1.5 7H22.5C23.3284 7 24 7.67157 24 8.5C24 9.32843 23.3284 10 22.5 10H1.5C0.671573 10 0 9.32843 0 8.5Z",
                fill: "white"
            }),
            /*#__PURE__*/ jsx_runtime.jsx("path", {
                d: "M0 15.5C0 14.6716 0.671573 14 1.5 14H26.5C27.3284 14 28 14.6716 28 15.5C28 16.3284 27.3284 17 26.5 17H1.5C0.671572 17 0 16.3284 0 15.5Z",
                fill: "white"
            })
        ]
    });
};
/* harmony default export */ const assets_Icon = (Icon);

// EXTERNAL MODULE: external "@mui/material/AppBar"
var AppBar_ = __webpack_require__(3882);
var AppBar_default = /*#__PURE__*/__webpack_require__.n(AppBar_);
// EXTERNAL MODULE: external "@mui/material/CssBaseline"
var CssBaseline_ = __webpack_require__(4960);
var CssBaseline_default = /*#__PURE__*/__webpack_require__.n(CssBaseline_);
// EXTERNAL MODULE: external "@mui/material/useScrollTrigger"
var useScrollTrigger_ = __webpack_require__(4156);
var useScrollTrigger_default = /*#__PURE__*/__webpack_require__.n(useScrollTrigger_);
// EXTERNAL MODULE: external "@mui/material/Slide"
var Slide_ = __webpack_require__(6080);
var Slide_default = /*#__PURE__*/__webpack_require__.n(Slide_);
;// CONCATENATED MODULE: ./src/widgets/header/index.tsx













function HideOnScroll(props) {
    const { children, window } = props;
    // Note that you normally won't need to set the window ref as useScrollTrigger
    // will default to window.
    // This is only being set here because the demo is in an iframe.
    const trigger = useScrollTrigger_default()({
        target: window ? window() : undefined
    });
    return /*#__PURE__*/ jsx_runtime.jsx((Slide_default()), {
        appear: false,
        direction: "down",
        in: !trigger,
        children: children
    });
}
function Header(props) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)((external_react_default()).Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx((CssBaseline_default()), {}),
            /*#__PURE__*/ jsx_runtime.jsx(HideOnScroll, {
                ...props,
                children: /*#__PURE__*/ jsx_runtime.jsx((AppBar_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: (header_module_default()).header,
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx("h1", {
                                children: "Tarixmanba.uz"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(mainButton/* default */.Z, {
                                title: "Manbalar",
                                Icon: assets_Icon
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "!",
                                            children: "Biz haqimizda"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "!",
                                            children: "Yangiliklar"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "!",
                                            children: "Kutubxona"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                                            href: "!",
                                            children: "Bog’lanish"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                src: Vector_10_,
                                                alt: "user"
                                            }),
                                            "Shaxsiy xona"
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                src: ic_baseline_remove_red_eye,
                                                alt: "Eye"
                                            }),
                                            "Zaif koʻruvchilar uchun"
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                })
            })
        ]
    });
} // const Header = () => {
 //      return (
 //      );
 // };
 // export default Header;

;// CONCATENATED MODULE: ./src/pages/_app.tsx





function MyApp({ Component, pageProps }) {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("title", {
                        children: "Tarix manba"
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("link", {
                        rel: "icon",
                        href: "/logo.svg"
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("main", {
                className: (proximanova_regular_ttf_variable_font_surt_bold_variableName_surt_default()).variable,
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx(Header, {
                        children: /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {})
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx(Component, {
                        ...pageProps
                    })
                ]
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 3104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6859);
/* harmony import */ var next_document__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_document__WEBPACK_IMPORTED_MODULE_1__);


class AppDocument extends (next_document__WEBPACK_IMPORTED_MODULE_1___default()) {
    render() {
        return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_1__.Html, {
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(next_document__WEBPACK_IMPORTED_MODULE_1__.Head, {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "preconnect",
                            href: "https://fonts.googleapis.com"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            rel: "preconnect",
                            href: "https://fonts.gstatic.com",
                            crossOrigin: "anonymous"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("link", {
                            href: "https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap",
                            rel: "stylesheet"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("body", {
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.Main, {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(next_document__WEBPACK_IMPORTED_MODULE_1__.NextScript, {})
                    ]
                })
            ]
        });
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AppDocument);


/***/ }),

/***/ 6501:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mainButton_module_scss__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4508);
/* harmony import */ var _mainButton_module_scss__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mainButton_module_scss__WEBPACK_IMPORTED_MODULE_2__);



const MainButton = ({ title, Icon })=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("button", {
        className: (_mainButton_module_scss__WEBPACK_IMPORTED_MODULE_2___default().mainButton),
        style: {
            fontSize: "14px",
            fontWeight: 700,
            lineHeight: "17px",
            letterSpacing: "0em",
            textAlign: "center",
            padding: "18px 28px",
            border: "none",
            outline: "none",
            color: "#fff",
            textTransform: "uppercase",
            display: "flex",
            alignItems: "center",
            gap: "10px",
            cursor: "pointer"
        },
        children: [
            title,
            " ",
            Icon ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(Icon, {}) : ""
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MainButton);


/***/ }),

/***/ 7195:
/***/ (() => {



/***/ })

};
;